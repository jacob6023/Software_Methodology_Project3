package prereqchecker;

import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * NeedToTakeInputFile name is passed through the command line as args[1]
 * Read from NeedToTakeInputFile with the format:
 * 1. One line, containing a course ID
 * 2. c (int): Number of courses
 * 3. c lines, each with one course ID
 * 
 * Step 3:
 * NeedToTakeOutputFile name is passed through the command line as args[2]
 * Output to NeedToTakeOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */
public class NeedToTake {
    public static void main(String[] args) {
        StdIn.setFile(args[0]);
        
        if ( args.length < 3 ) {
            StdOut.println("Execute: java NeedToTake <adjacency list INput file> <need to take INput file> <need to take OUTput file>");
            return;
        }
        ArrayList<String> firstList = new ArrayList<>();
        int a = StdIn.readInt();

        for (int i = 0; i < a; ++i) {
            firstList.add(StdIn.readString());
        }
        ArrayList<String>[] list = new ArrayList[a];
        for (int i = 0; i < a; ++i) {
            list[i] = new ArrayList<>();
        }
        
        int b = StdIn.readInt();
        
        for (int i = 0; i < b; ++i) {
            String course = StdIn.readString();
            String prereq = StdIn.readString();
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(course)) {
                    list[j].add(prereq);
                    break;
                }
            }
        }
        // Go BFS to search and add elements for each list
        // Then, target - (takens)

        // Or using hashmap for searching on the target one 
        // to help find the prereqs are met while searching.
        StdIn.setFile(args[1]);
        StdOut.setFile(args[2]);

        String target = StdIn.readString(); // target courses

        int d = StdIn.readInt();
        HashSet<String> set = new HashSet<>();
        boolean[] visited = new boolean[firstList.size()];
        for (int i = 0; i < d; ++i) { 
            String s = StdIn.readString(); // taken courses
            visited = new boolean[firstList.size()];
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(s) && !visited[j]) {
                    set.add(s); 
                    dfs(visited, j, list, set, firstList);
                }
            }
        }
    
        ArrayList<String> storage = new ArrayList<>();
        visited = new boolean[firstList.size()];
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(target) && !visited[j]) {
                    dfstarget(visited, j, list, set, firstList, storage);
                }
            }

        for (int i = 0; i < storage.size(); ++i) {
            StdOut.println(storage.get(i));
        }
        
    }

    private static void dfs(boolean[] visited, int j, ArrayList<String>[] list, HashSet<String> set, ArrayList<String> firstList) {
        visited[j] = true;
        for (int k = 0; k < list[j].size(); ++k) {
            int u = 0;
            for (int l = 0; l < firstList.size(); ++l) {
                if (list[j].get(k).equals(firstList.get(l))) {
                    u = l;
                    break;
                }
            }
            if (!visited[u]) {
                set.add(list[j].get(k));
                dfs(visited, u, list, set, firstList);
            }
        }
    }


    private static void dfstarget(boolean[] visited, int j, ArrayList<String>[] list, HashSet<String> set, ArrayList<String> firstList, ArrayList<String> storage) {
        visited[j] = true;
        for (int k = 0; k < list[j].size(); ++k) {
            int u = 0;
            for (int l = 0; l < firstList.size(); ++l) {
                if (list[j].get(k).equals(firstList.get(l))) {
                    u = l;
                    break;
                }
            }
            if (!visited[u] && !set.contains(list[j].get(k))) {
                storage.add(list[j].get(k));
                dfstarget(visited, u, list, set, firstList, storage);
            }
        }
    }
}
