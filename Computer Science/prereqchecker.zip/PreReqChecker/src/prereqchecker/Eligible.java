package prereqchecker;
import java.util.*;

/**
 * 
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * EligibleInputFile name is passed through the command line as args[1]
 * Read from EligibleInputFile with the format:
 * 1. c (int): Number of courses
 * 2. c lines, each with 1 course ID
 * 
 * Step 3:
 * EligibleOutputFile name is passed through the command line as args[2]
 * Output to EligibleOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */
public class Eligible {
    public static void main(String[] args) { // like DFS for digraph without recursion.

        StdIn.setFile(args[0]);
        
        
        if ( args.length < 3 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.Eligible <adjacency list INput file> <eligible INput file> <eligible OUTput file>");
            return;
        }

        ArrayList<String> firstList = new ArrayList<>();
        int a = StdIn.readInt();

        for (int i = 0; i < a; ++i) {
            firstList.add(StdIn.readString());
        }
        ArrayList<String>[] list = new ArrayList[a];
        for (int i = 0; i < a; ++i) {
            list[i] = new ArrayList<>();
        }
        
        int b = StdIn.readInt();
        
        for (int i = 0; i < b; ++i) {
            String course = StdIn.readString();
            String prereq = StdIn.readString();
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(course)) {
                    list[j].add(prereq);
                    break;
                }
            }
        }
        // <<<Idea>>>
        // As you take the prereq of courses in input file out using dfs,
        // you just check which courses are elgible
        // to be taken by input courses including what you've taken out.
        
        StdIn.setFile(args[1]);
        StdOut.setFile(args[2]);
        int c = StdIn.readInt();
        HashSet<String> ocs = new HashSet<>();
        boolean[] marked = new boolean[firstList.size()];
        for (int i = 0; i < c; ++i) { // DFS --> Got This
            String s = StdIn.readString();
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(s) && !marked[j]) {
                    ocs.add(s); 
                    dfs(marked, j, list, ocs, firstList);
                    break;
                }
            }
        }
        int count = 0;
        ArrayList<String> second = new ArrayList<>();
        
        for (int i = 0; i < firstList.size(); ++i) { // to find which courses you are elgible to take once you takethe  given courses.
            for (int j = 0; j < list[i].size(); ++j) {
                if (ocs.contains(list[i].get(j))) {
                    count++;
                }
                if (count == list[i].size()) {
                    second.add(firstList.get(i));
                }
            }
            count = 0;
        }
        
         //  to fix cause' I have changed the structure for ocs.
        for (int j = 0; j < second.size(); ++j) {
            if (ocs.contains(second.get(j))) {
                second.remove(j);
                j--;
            }
        }   
        
        
        for (int i = 0; i < second.size(); ++i) {
            StdOut.print(second.get(i) + " ");
            StdOut.println();
        }
    }

    private static void dfs(boolean[] marked, int j, ArrayList<String>[] list, HashSet<String> ocs, ArrayList<String> firstList) {
        marked[j] = true;
        for (int k = 0; k < list[j].size(); ++k) {
            int u = 0;
            for (int l = 0; l < firstList.size(); ++l) {
                if (list[j].get(k).equals(firstList.get(l))) {
                    u = l;
                    break;
                }
            }
            if (!marked[u]) {
                ocs.add(list[j].get(k));
                dfs(marked, u, list, ocs, firstList);
            }
        }
    }
}
