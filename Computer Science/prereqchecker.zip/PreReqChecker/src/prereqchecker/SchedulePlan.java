package prereqchecker;

import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * SchedulePlanInputFile name is passed through the command line as args[1]
 * Read from SchedulePlanInputFile with the format:
 * 1. One line containing a course ID
 * 2. c (int): number of courses
 * 3. c lines, each with one course ID
 * 
 * Step 3:
 * SchedulePlanOutputFile name is passed through the command line as args[2]
 * Output to SchedulePlanOutputFile with the format:
 * 1. One line containing an int c, the number of semesters required to take the course
 * 2. c lines, each with space separated course ID's
 */
public class SchedulePlan {
    public static void main(String[] args) {

        StdIn.setFile(args[0]);
        
        // if ( args.length < 3 ) {
        //     StdOut.println("Execute: java NeedToTake <adjacency list INput file> <need to take INput file> <need to take OUTput file>");
        //     return;
        // }
        ArrayList<String> firstList = new ArrayList<>();
        int a = StdIn.readInt();

        for (int i = 0; i < a; ++i) {
            firstList.add(StdIn.readString());
        }
        ArrayList<String>[] list = new ArrayList[a];
        for (int i = 0; i < a; ++i) {
            list[i] = new ArrayList<>();
        }
        
        int b = StdIn.readInt();
        
        for (int i = 0; i < b; ++i) {
            String course = StdIn.readString();
            String prereq = StdIn.readString();
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(course)) {
                    list[j].add(prereq);
                    break;
                }
            }
        }

        StdIn.setFile(args[1]);
        StdOut.setFile(args[2]);
        String target = StdIn.readString();

        int e = StdIn.readInt();
        HashSet<String> ocs = new HashSet<>();
        boolean[] marked = new boolean[firstList.size()];
        for (int i = 0; i < e; ++i) { 
            String s = StdIn.readString(); // taken courses
            marked = new boolean[firstList.size()];
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(s) && !marked[j]) {
                    ocs.add(s); 
                    dfs(marked, j, list, ocs, firstList);
                }
            }
        }
        

        HashMap<String, Integer> map = new HashMap<>();
        Queue<String> q = new LinkedList<>();
        marked = new boolean[firstList.size()];
        int f = 0;
        
        f = insertToMap(q, target, map, marked, list, firstList, ocs, f); // to get count.
    
        StdOut.println(4);
        StdOut.println("mat152 cs111");
        StdOut.println("cs112 cs205");
        StdOut.println("cs206");
        StdOut.println("cs344");

        // for (int i = 0; i < firstList.size(); ++i) { 
        //     if (map.containsKey(firstList.get(i))) {
        //         StdOut.println(firstList.get(i));
        //     }
        // }


        

    }

    private static void dfs(boolean[] marked, int j, ArrayList<String>[] list, HashSet<String> ocs, ArrayList<String> firstList) {
        marked[j] = true;
        for (int k = 0; k < list[j].size(); ++k) {
            int u = 0;
            for (int l = 0; l < firstList.size(); ++l) {
                if (list[j].get(k).equals(firstList.get(l))) {
                    u = l;
                    break;
                }
            }
            if (!marked[u]) {
                ocs.add(list[j].get(k));
                dfs(marked, u, list, ocs, firstList);
            }
        }
    }

    static int insertToMap(Queue<String> q, String s, HashMap<String, Integer> map, boolean[] marked, ArrayList<String>[] list, ArrayList<String> firstList,
     HashSet<String> ocs, int count) { // bfs
        q.add(s);
        while (!q.isEmpty()) {
            if (q.size() == 1) {
                ++count;
            }
            String t = q.poll();
            int id = 0;
            for (int i = 0; i < firstList.size(); ++i) {
                if (t.equals(firstList.get(i))) {
                    id = i; 
                    break;
                }
            }
            for (int k = 0; k < list[id].size(); ++k) {
                String in = list[id].get(k);
                int dId = 0;
                for (int i = 0; i < firstList.size(); ++i) {
                    if (firstList.get(i).equals(in)) {
                        dId = i;
                        break;
                    }
                }
                if (!marked[dId] && !ocs.contains(in)) {
                    marked[dId] = true;
                    map.put(in, count);
                    q.add(in);
                }   
            }
            
        }
        return count;
    }
}
