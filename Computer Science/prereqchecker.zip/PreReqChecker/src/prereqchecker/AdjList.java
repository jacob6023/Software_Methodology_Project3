package prereqchecker;
import java.util.*;
/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * AdjListOutputFile name is passed through the command line as args[1]
 * Output to AdjListOutputFile with the format:
 * 1. c lines, each starting with a different course ID, then 
 *    listing all of that course's prerequisites (space separated)
 */
public class AdjList {
    public static void main(String[] args) {

        StdIn.setFile(args[0]);
        StdOut.setFile(args[1]);

        if ( args.length < 2 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.AdjList <adjacency list INput file> <adjacency list OUTput file>");
            return;
        }

        ArrayList<String> firstList = new ArrayList<>();
        int a = StdIn.readInt();

        for (int i = 0; i < a; ++i) {
            firstList.add(StdIn.readString());
        }
        ArrayList<String>[] list = new ArrayList[a];
        for (int i = 0; i < a; ++i) {
            list[i] = new ArrayList<>();
        }
        
        int b = StdIn.readInt();
        
        for (int i = 0; i < b; ++i) {
            String course = StdIn.readString();
            String prereq = StdIn.readString();
            for (int j = 0; j < firstList.size(); ++j) {
                if (firstList.get(j).equals(course)) {
                    list[j].add(prereq);
                    break;
                }
            }
        }
        for (int i = 0; i < a; ++i) {
            StdOut.print(firstList.get(i) + " ");
            for (int j = 0; j < list[i].size(); ++j) {
                StdOut.print(list[i].get(j) + " ");
            }
            StdOut.println();
        }

    }

    public static HashMap<String, ArrayList<String>> fileToList(String fileName) {
        StdIn.setFile(fileName);
        HashMap<String, ArrayList<String>> courses = new HashMap<>();
        int n = StdIn.readInt();
        StdIn.readLine();
        for (int i = 0; i < n; i++) {
            String course = StdIn.readString();
            courses.put(course, new ArrayList<String>());
            StdIn.readLine();
        }
        n = StdIn.readInt();
        StdIn.readLine();
        for (int i = 0; i < n; i++) {
            String course = StdIn.readString();
            ArrayList<String> prereqs = courses.get(course);
            String prereq = StdIn.readString();
            prereqs.add(prereq);
            courses.put(course, prereqs);
            StdIn.readLine();
        }
        return courses;
    }
}
