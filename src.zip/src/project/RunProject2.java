package clinic.src.project;

public class RunProject2 {
    /*  This is a driver class that runs your software. The graders will run this class to grade  your project. */
    public static void main(String [] args) {
        new ClinicManager().run();
    }

}
